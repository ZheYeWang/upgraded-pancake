package com.serverImpl;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.bean.T_User;
import com.bean.UserForm;
import com.dao.BaseDao;
import com.dao.hibernateDao;
import com.daoImpl.HibernateSessionFactory;
import com.daoImpl.UserDao;
import com.server.UserManaer;

import org.hibernate.HibernateException;  

public class UserManagerImpl implements UserManaer {

	private BaseDao baseDao;
	private Session session;
	public UserManagerImpl(){
		baseDao = new UserDao();
	}
	@Override
	public void regUser(UserForm userForm) {
		System.out.println("UserManagerImpl");
		
		 session = HibernateSessionFactory.getSession();  
	        baseDao.setSession(session);  
	        // ��ȡ����  
	        Transaction ts = session.beginTransaction();  
	        // ����User����  
	        T_User user = new T_User();  
	        user.setUserName(userForm.getUserName());  
	        user.setPassWord(userForm.getPassWord());  
	       
//	       hibernateDao hbdao = new hibernateDao();
//	       hbdao.add(user);
	        // ����User����  
	        baseDao.saveObject(user);  
	        // �ύ����  
	        ts.commit();  
	        // �ر�Session  
	        HibernateSessionFactory.closeSession();  
	}

}
