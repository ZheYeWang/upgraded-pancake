package com.server;

import com.bean.T_User;
import com.bean.UserForm;

public interface UserManaer {

	public void regUser(UserForm user);
}
