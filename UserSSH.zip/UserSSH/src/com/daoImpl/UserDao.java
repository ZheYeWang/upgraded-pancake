package com.daoImpl;


import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.dao.BaseDao;

public class UserDao implements BaseDao {
	
	  private Session session;  
	@Override
	public void saveObject(Object obj) throws HibernateException {
		System.out.println("������userdao");
		// TODO Auto-generated method stub
		 session.save(obj);  
	}

	@Override
	public Session getSession() {
		// TODO Auto-generated method stub
		return session;
	}

	@Override
	public void setSession(Session session) {
		this.session = session;

	}

}
