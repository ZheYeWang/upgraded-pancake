package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;  
import org.hibernate.Session;  
import org.hibernate.SessionFactory;  
import org.hibernate.Transaction;  
import org.hibernate.cfg.Configuration;  
import org.hibernate.service.ServiceRegistry;  
import org.hibernate.service.ServiceRegistryBuilder; 

public class hibernateDao{
	private static SessionFactory sessionFactory;  
    
	 /** 
	 * @return ��ȡ�Ự���� 
	 */  
	  public static SessionFactory getSessionFactory()  
	  {  
		  System.out.println("22222222222222");
	    //��һ��:��ȡHibernate�������ļ�  hibernamte.cfg.xml�ļ�  
	    Configuration con=new Configuration().configure();  
	    //�ڶ���:��������ע�ṹ��������ͨ�����ö����м������е�������Ϣ  
	    ServiceRegistryBuilder regbulider=new ServiceRegistryBuilder().applySettings(con.getProperties());  
	    //����ע�����  
	    ServiceRegistry reg=regbulider.buildServiceRegistry();  
	    //������:�����Ự����  
	    SessionFactory sessionFactory=con.buildSessionFactory(reg);  
	    return sessionFactory;  
	  }  
	    
	 /** 
	 * @return ��ȡ�Ự���� 
	 */  
	  public static Session getSession()  
	  {  
	     return getSessionFactory().openSession();  
	  }  
	    
	  /** 
	 * @param obj �������� 
	 * @return 
	 */  
	  public static boolean add(Object obj)  
	  {  
	    Session session=null;  
	    Transaction tran=null;  
	    boolean result=false;  
	    try  
	    {  
	        session=getSession();  
	        tran=session.beginTransaction();  
	        session.save(obj);  
	        tran.commit();  
	        result=true;  
	    }  
	    catch (Exception e)  
	    {  
	       if(tran!=null)  
	       {  
	           //����ع�  
	           tran.rollback();  
	       }  
	    }  
	    finally  
	    {  
	        if(session!=null)  
	        {  
	            //�ر�session  
	            session.close();  
	        }  
	    }  
	    return result;  
	  }  
	    
	  /** 
	 * @return ��������  
	 * ����Ϊ�޸ĵ�����id���� 
	 */  
	public static boolean update(Object object)  
	  {  
	        Session session=null;  
	        Transaction tran=null;  
	        boolean result=false;  
	        try  
	        {  
	            session=getSession();  
	            tran=session.beginTransaction();  
	            session.update(object);  
	            tran.commit();  
	            result=true;  
	        }  
	        catch (Exception e)  
	        {  
	           if(tran!=null)  
	           {  
	               //����ع�  
	               tran.rollback();  
	           }  
	        }  
	        finally  
	        {  
	            if(session!=null)  
	            {  
	                //�ر�session  
	                session.close();  
	            }  
	        }  
	        return result;  
	      }  
	       
	  /** 
	 * @param c 
	 * @param obj  ��ѯһ�����ݸ���������id�� 
	 * @return 
	 */  
	  public static Object get(Class c,String obj)  
	  {  
		  System.out.println("33333333");
		  Session session=null;  
	        Object object=null;  
	        try  
	        {  
	            session=getSession();  
	            object=session.get(c,obj);  
	        }  
	        catch (Exception e)  
	        {  
	        }  
	        finally  
	        {  
	            if(session!=null)  
	            {  
	                //�ر�session  
	                session.close();  
	            }  
	        }  
	        return object;  
	  }  
	  public static Object get1(Class c,int obj)  
	  {  
		  Session session=null;  
	        Object object=null;  
	        try  
	        {  
	            session=getSession();  
	            object=session.get(c,obj);  
	        }  
	        catch (Exception e)  
	        {  
	        }  
	        finally  
	        {  
	            if(session!=null)  
	            {  
	                //�ر�session  
	                session.close();  
	            }  
	        }  
	        return object;  
	  }  
	  /** 
	 * @param obj 
	 * @return ɾ������ 
	 */  
	public static boolean delete(Object obj)  
	  {  
	        Session session=null;  
	        Transaction tran=null;  
	        boolean result=false;  
	        try  
	        {  
	            session=getSession();  
	            tran=session.beginTransaction();  
	            session.delete(obj);  
	            tran.commit();  
	            result=true;  
	        }  
	        catch (Exception e)  
	        {  
	           if(tran!=null)  
	           {  
	               //����ع�  
	               tran.rollback();  
	           }  
	        }  
	        finally  
	        {  
	            if(session!=null)  
	            {  
	                //�ر�session  
	                session.close();  
	            }  
	        }  
	        return result;  
	  }  
	  
	  
	  /** 
	 * @param <T> ��ѯ������¼ 
	 * @param sql  sql��� 
	 * @param param �������� 
	 * @return 
	 */  
	 @SuppressWarnings("unchecked")  
	public static <T> List<T> query(String sql)  
	  {  
	      List<T> list=new ArrayList<T>();  
	      Session session=null;  
	       try  
	        {  
	            session=getSession();  
	            Query query=session.createQuery(sql);  
	           
	            list=query.list();  
	        }  
	        catch (Exception e)  
	        {  
	        }  
	        finally  
	        {  
	            if(session!=null)  
	            {  
	                session.close();  
	            }  
	        }  
	      return list;  
	  }  
	  /** 
	 * @param sql 
	 * @param param ��ѯ������¼ 
	 * @return 
	 */  
	public static Object queryOne(String sql)  
	  {  
	      Object object=null;  
	      Session session=null;  
	       try  
	        {  
	            session=getSession();  
	            Query query=session.createQuery(sql);  
	             
	                object=query.uniqueResult();  
	             
	        }  
	        catch (Exception e)  
	        {  
	        }  
	        finally  
	        {  
	            if(session!=null)  
	            {  
	                session.close();  
	            }  
	        }  
	      return object;  
	  }  

	
    /**
     * ʹ��hibernate�ṩ�ķ�ҳ���ܣ��õ���ҳ��ʾ������
     */
     @SuppressWarnings("unchecked")
    public  <T> List<T>  queryByPage(String hql, int offset, int pageSize)
    {
    	 List<T> list=new ArrayList<T>();  
	      Session session=null;  
	       try  
	        {  
	            session=getSession();  
	            Query query=session.createQuery(hql);  
		           
	            //ɸѡ����  
	            query.setFirstResult(offset);  
	            query.setMaxResults(pageSize);  
	            list=query.list();  
	           
	        }  
	        catch (Exception e)  
	        {  
	        }  
	        finally  
	        {  
	            if(session!=null)  
	            {  
	                session.close();  
	            }  
	        }  
	      return list;  
     }
     /**
      * ͨ��hql���õ����ݿ��м�¼����
      */
 	     public int getAllRowCount(String hql)
 	     {
 	         Session session=null;  
 		    
 		         
 	         int allRows = 0;
 	         try
 	         {
 	        	   session=getSession(); 
 	             
 	             Query query = session.createQuery(hql);
 	             
 	             allRows = query.list().size();
 	             
 	             
 	         }
 	         catch (Exception e)
 	         {
 	            
 	         }
 	         finally
 	         {
 	        	  if(session!=null)  
 		            {  
 		                session.close();  
 		            }  
 	         }
 	         
 	         return allRows;
 	     }

	/*@SuppressWarnings("unchecked")  
	public static <T> List<T> queryByPage(String sql,String[] param,int page,int size)  
	  {  
	      List<T> list=new ArrayList<T>();  
	      Session session=null;  
	       try  
	        {  
	            session=getSession();  
	            Query query=session.createQuery(sql);  
	            if(param!=null)  
	            {  
	                for(int i=0;i<param.length;i++)  
	                {  
	                    query.setString(i,param[i]);      
	                }  
	            }  
	            //ɸѡ����  
	            query.setFirstResult((page-1)*size);  
	            query.setMaxResults(size);  
	            list=query.list();  
	        }  
	        catch (Exception e)  
	        {  
	        }  
	        finally  
	        {  
	            if(session!=null)  
	            {  
	                session.close();  
	            }  
	        }  
	      return list;  
	  }  */
	/** 
	 * @param hql 
	 * @param pras 
	 * @return�������ݸ��� 
	 */  
	public static int getCount(String hql, String[] pras) {  
	    int resu = 0;  
	    Session s = null;  
	    try {  
	        s = getSession();  
	        Query q = s.createQuery(hql);  
	        if (pras != null) {  
	            for (int i = 0; i < pras.length; i++) {  
	                q.setString(i, pras[i]);  
	            }  
	        }  
	        resu = Integer.valueOf(q.iterate().next().toString());  
	    } catch (Exception e) {  
	        e.printStackTrace();  
	    } finally {  
	        if (s != null)  
	            s.close();  
	    }  
	    return resu;  
	}

	
	
	
}
